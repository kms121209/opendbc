from opendbc.car.structs import CarParams

Ecu = CarParams.Ecu

FW_VERSIONS_EXT = {
}
